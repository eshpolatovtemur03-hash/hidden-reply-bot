import logging
import os
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, HTTPServer

from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQueryResultArticle,
    InputTextMessageContent,
)
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    InlineQueryHandler,
    ContextTypes,
    filters,
)
from telegram.constants import ParseMode

from database import (
    init_db,
    store_message,
    get_message,
    mark_read,
    delete_expired,
    get_stats,
    get_mystats_detail,
    get_leaderboard,
    get_user_count,
    upsert_user,
)

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

BOT_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]

DEFAULT_EXPIRY_SECONDS = 86400  # 24 hours


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    now = int(time.time())
    await upsert_user(user.id, user.username, user.first_name, now)
    await update.message.reply_text(
        "👋 *Hidden Message Bot*\n\n"
        "Send secret messages that only the intended recipient can read!\n\n"
        "*How to use in a group (reply mode):*\n"
        "1. Reply to someone's message and tag me with your secret text\n"
        "   e.g. `@thisbot Hello, this is private!`\n"
        "2. Only that person can tap to read it\n\n"
        "*How to use anywhere (inline mode):*\n"
        "1. In any chat, type `@thisbot your secret message`\n"
        "2. Select *Send as hidden message* from the list\n"
        "3. Anyone in the chat can tap to reveal it\n\n"
        "*Commands:*\n"
        "/mystats — detailed personal breakdown\n"
        "/leaderboard — top senders in the group\n"
        "/stats — quick sent/received count\n"
        "/help — show this help\n\n"
        "Hidden messages expire automatically after 24 hours.",
        parse_mode=ParseMode.MARKDOWN,
    )


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await start(update, context)


async def stats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    now = int(time.time())
    await upsert_user(user.id, user.username, user.first_name, now)
    row = await get_stats(user.id)
    if not row:
        await update.message.reply_text("No stats yet. Send your first hidden message!")
        return
    sent = row.get("sent_count", 0)
    received = row.get("received_count", 0)
    await update.message.reply_text(
        f"📊 *Your Stats*\n\n"
        f"✉️ Hidden messages sent: *{sent}*\n"
        f"📬 Hidden messages received: *{received}*",
        parse_mode=ParseMode.MARKDOWN,
    )


async def mystats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    now = int(time.time())
    await upsert_user(user.id, user.username, user.first_name, now)
    data = await get_mystats_detail(user.id)
    if not data or (data.get("sent_count", 0) == 0 and data.get("received_count", 0) == 0):
        await update.message.reply_text(
            "You haven't sent or received any hidden messages yet. Get started! 🕵️"
        )
        return

    sent = data.get("sent_count", 0)
    received = data.get("received_count", 0)
    read_count = data.get("read_count", 0)

    if sent > 0:
        read_rate = int((read_count / sent) * 100)
    else:
        read_rate = 0

    top_name = data.get("top_recipient_name")
    top_cnt = data.get("top_recipient_cnt", 0)

    lines = [f"🕵️ *Your Hidden Message Stats*\n"]
    lines.append(f"✉️ Messages sent: *{sent}*")
    lines.append(f"📬 Messages received: *{received}*")
    lines.append(f"👁 Your messages read: *{read_count}/{sent}* ({read_rate}%)")
    if top_name and top_cnt:
        lines.append(f"💌 Top recipient: *{top_name}* ({top_cnt} messages)")

    await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)


async def users_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    count = await get_user_count()
    await update.message.reply_text(
        f"👥 *Total unique users:* {count}",
        parse_mode=ParseMode.MARKDOWN,
    )


async def handle_mention(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle a message that mentions the bot (in group or private)."""
    message = update.message
    if not message:
        return

    user = message.from_user
    now = int(time.time())
    await upsert_user(user.id, user.username, user.first_name, now)

    # Determine recipient: must be a reply
    if not message.reply_to_message:
        await message.reply_text(
            "⚠️ To send a hidden message, *reply to the target person's message* and tag me.",
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    recipient = message.reply_to_message.from_user
    if not recipient or recipient.is_bot:
        await message.reply_text("❌ You can't send a hidden message to a bot.")
        return

    if recipient.id == user.id:
        await message.reply_text("❌ You can't send a hidden message to yourself.")
        return

    # Detect content type
    content_type = "text"
    text = None
    file_id = None

    if message.voice:
        content_type = "voice"
        file_id = message.voice.file_id
    elif message.photo:
        content_type = "photo"
        file_id = message.photo[-1].file_id
        text = message.caption
    elif message.video:
        content_type = "video"
        file_id = message.video.file_id
        text = message.caption
    else:
        raw = message.text or ""
        bot_username = context.bot.username
        text = raw.replace(f"@{bot_username}", "").strip()
        if not text:
            await message.reply_text(
                "⚠️ Please include a message after tagging me.",
                parse_mode=ParseMode.MARKDOWN,
            )
            return

    # Delete the original message immediately — before anything else
    try:
        await message.delete()
    except Exception as e:
        logger.warning("Could not delete original message (bot may lack admin rights): %s", e)

    # Store with default 24-hour expiry and post locked card
    message_id = str(uuid.uuid4())
    expires_at = now + DEFAULT_EXPIRY_SECONDS

    await store_message(
        message_id=message_id,
        sender_id=user.id,
        recipient_id=recipient.id,
        content_type=content_type,
        text=text,
        file_id=file_id,
        created_at=now,
        expires_at=expires_at,
    )

    reveal_button = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔓 Read hidden message", callback_data=f"read:{message_id}")]
    ])

    await context.bot.send_message(
        chat_id=message.chat_id,
        text="🔒 *Hidden message*\n⏳ Expires: 24 hours",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=reveal_button,
    )


async def read_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Called when someone taps the 'Read hidden message' button."""
    query = update.callback_query
    _, message_id = query.data.split(":", 1)
    user = query.from_user
    now = int(time.time())

    row = await get_message(message_id)
    if not row:
        await query.answer("❌ This message has been deleted or expired.", show_alert=True)
        return

    if now > row["expires_at"]:
        await query.answer("⌛ This message has expired.", show_alert=True)
        return

    # recipient_id == 0 means inline mode — anyone in the chat can read
    if row["recipient_id"] != 0 and user.id != row["recipient_id"]:
        await query.answer("🔒 You cannot read this message.", show_alert=True)
        return

    # Mark as read
    await mark_read(message_id, now)
    await upsert_user(user.id, user.username, user.first_name, now)

    content_type = row["content_type"]

    if content_type == "text":
        # Show text directly as a popup in the group (max 200 chars)
        text = row["text"] or ""
        popup = text if len(text) <= 200 else text[:197] + "…"
        await query.answer(text=popup, show_alert=True)
    else:
        # For media, acknowledge the tap then post to the group chat
        await query.answer()
        chat_id = query.message.chat_id
        if content_type == "voice":
            await context.bot.send_voice(
                chat_id=chat_id,
                voice=row["file_id"],
                caption=f"🔓 Hidden voice message for {user.first_name}",
            )
        elif content_type == "photo":
            await context.bot.send_photo(
                chat_id=chat_id,
                photo=row["file_id"],
                caption=(
                    f"🔓 Hidden photo for {user.first_name}"
                    + (f": {row['text']}" if row["text"] else "")
                ),
            )
        elif content_type == "video":
            await context.bot.send_video(
                chat_id=chat_id,
                video=row["file_id"],
                caption=(
                    f"🔓 Hidden video for {user.first_name}"
                    + (f": {row['text']}" if row["text"] else "")
                ),
            )


async def handle_inline_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle inline queries: @botname <secret text>"""
    query = update.inline_query
    user = query.from_user
    text = (query.query or "").strip()
    logger.info("Inline query from user %s: %r", user.id, text)

    if not text:
        placeholder = InlineQueryResultArticle(
            id="help",
            title="🔒 Send a hidden message",
            description="Keep typing your secret message…",
            input_message_content=InputTextMessageContent(
                message_text=(
                    "ℹ️ To send a hidden message, type:\n"
                    "`@hiddenreply_bot your secret text`\n\n"
                    "Anyone in the chat can tap to reveal it."
                ),
                parse_mode=ParseMode.MARKDOWN,
            ),
        )
        await query.answer(results=[placeholder], cache_time=0)
        return

    now = int(time.time())
    await upsert_user(user.id, user.username, user.first_name, now)

    # Store immediately so the callback_data UUID resolves when tapped
    message_id = str(uuid.uuid4())
    expires_at = now + DEFAULT_EXPIRY_SECONDS

    await store_message(
        message_id=message_id,
        sender_id=user.id,
        recipient_id=0,  # 0 = anyone in this chat can read
        content_type="text",
        text=text,
        file_id=None,
        created_at=now,
        expires_at=expires_at,
    )

    reveal_button = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔓 Read hidden message", callback_data=f"read:{message_id}")]
    ])

    preview = text if len(text) <= 40 else text[:37] + "…"
    result = InlineQueryResultArticle(
        id=message_id,
        title="🔒 Send as hidden message",
        description=preview,
        input_message_content=InputTextMessageContent(
            message_text="🔒 *Hidden message*\n⏳ Expires: 24 hours",
            parse_mode=ParseMode.MARKDOWN,
        ),
        reply_markup=reveal_button,
    )

    await query.answer(results=[result], cache_time=0)


async def leaderboard_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rows = await get_leaderboard(limit=10)
    if not rows:
        await update.message.reply_text("No hidden messages sent yet. Be the first! 🕵️")
        return

    medals = ["🥇", "🥈", "🥉"]
    lines = ["🏆 *Hidden Message Leaderboard* 🏆\n"]
    for i, row in enumerate(rows):
        rank = medals[i] if i < 3 else f"{i + 1}."
        name = row.get("first_name") or "Unknown"
        username = row.get("username")
        display = f"@{username}" if username else name
        sent = row["sent_count"]
        lines.append(f"{rank} {display} — *{sent}* sent")

    await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)


class _HealthHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(b"OK")

    def log_message(self, format, *args):
        pass  # suppress per-request access logs


def _start_health_server():
    port = int(os.environ.get("PORT", 8000))
    server = HTTPServer(("0.0.0.0", port), _HealthHandler)
    logger.info("Health check server listening on port %d", port)
    server.serve_forever()


async def cleanup_expired(context: ContextTypes.DEFAULT_TYPE):
    """Periodic job to remove expired messages from DB."""
    now = int(time.time())
    await delete_expired(now)


async def post_init(application: Application):
    await init_db()
    logger.info("Database initialized.")
    me = await application.bot.get_me()
    if me.supports_inline_queries:
        logger.info("Inline mode: ENABLED (BotFather setting is ON)")
    else:
        logger.warning(
            "Inline mode: DISABLED — go to BotFather → /mybots → your bot → "
            "Bot Settings → Inline Mode → Turn ON, then restart the bot."
        )


def main():
    application = (
        Application.builder()
        .token(BOT_TOKEN)
        .post_init(post_init)
        .build()
    )

    # Command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_cmd))
    application.add_handler(CommandHandler("stats", stats_cmd))
    application.add_handler(CommandHandler("mystats", mystats_cmd))
    application.add_handler(CommandHandler("leaderboard", leaderboard_cmd))
    application.add_handler(CommandHandler("users", users_cmd))

    # Mention handler: any message that mentions the bot in a group
    application.add_handler(
        MessageHandler(
            (filters.TEXT | filters.VOICE | filters.PHOTO | filters.VIDEO)
            & filters.Entity("mention"),
            handle_mention,
        )
    )

    # Inline query handler
    application.add_handler(InlineQueryHandler(handle_inline_query))

    # Callback query handlers
    application.add_handler(CallbackQueryHandler(read_message, pattern=r"^read:"))

    # Periodic cleanup every 5 minutes
    application.job_queue.run_repeating(cleanup_expired, interval=300, first=60)

    threading.Thread(target=_start_health_server, daemon=True).start()

    logger.info("Bot starting...")
    application.run_polling(
        allowed_updates=[
            "message",
            "edited_message",
            "callback_query",
            "inline_query",
            "chosen_inline_result",
        ]
    )


if __name__ == "__main__":
    main()
