import aiosqlite
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "bot_data.db")


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS hidden_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message_id TEXT UNIQUE NOT NULL,
                sender_id INTEGER NOT NULL,
                recipient_id INTEGER NOT NULL,
                content_type TEXT NOT NULL,
                text TEXT,
                file_id TEXT,
                created_at INTEGER NOT NULL,
                expires_at INTEGER NOT NULL,
                read_at INTEGER
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS user_stats (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                sent_count INTEGER DEFAULT 0,
                received_count INTEGER DEFAULT 0,
                last_seen INTEGER NOT NULL
            )
        """)
        await db.commit()


async def store_message(message_id: str, sender_id: int, recipient_id: int,
                        content_type: str, text: str | None, file_id: str | None,
                        created_at: int, expires_at: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            INSERT INTO hidden_messages
                (message_id, sender_id, recipient_id, content_type, text, file_id, created_at, expires_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (message_id, sender_id, recipient_id, content_type, text, file_id, created_at, expires_at))
        await db.execute("""
            INSERT INTO user_stats (user_id, sent_count, last_seen)
            VALUES (?, 1, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                sent_count = sent_count + 1,
                last_seen = excluded.last_seen
        """, (sender_id, created_at))
        await db.execute("""
            INSERT INTO user_stats (user_id, received_count, last_seen)
            VALUES (?, 1, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                received_count = received_count + 1,
                last_seen = excluded.last_seen
        """, (recipient_id, created_at))
        await db.commit()


async def get_message(message_id: str):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM hidden_messages WHERE message_id = ?", (message_id,)
        ) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None


async def mark_read(message_id: str, read_at: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE hidden_messages SET read_at = ? WHERE message_id = ?",
            (read_at, message_id)
        )
        await db.commit()


async def delete_expired(now: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "DELETE FROM hidden_messages WHERE expires_at <= ?", (now,)
        )
        await db.commit()


async def get_stats(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM user_stats WHERE user_id = ?", (user_id,)
        ) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None


async def get_mystats_detail(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM user_stats WHERE user_id = ?", (user_id,)
        ) as cursor:
            row = await cursor.fetchone()
            base = dict(row) if row else None

        if not base:
            return None

        async with db.execute(
            "SELECT COUNT(*) as total FROM hidden_messages WHERE sender_id = ? AND read_at IS NOT NULL",
            (user_id,)
        ) as cursor:
            row = await cursor.fetchone()
            read_count = row["total"] if row else 0

        async with db.execute("""
            SELECT recipient_id, COUNT(*) as cnt
            FROM hidden_messages
            WHERE sender_id = ?
            GROUP BY recipient_id
            ORDER BY cnt DESC
            LIMIT 1
        """, (user_id,)) as cursor:
            row = await cursor.fetchone()
            top_recipient_id = row["recipient_id"] if row else None
            top_recipient_cnt = row["cnt"] if row else 0

        top_recipient_name = None
        if top_recipient_id:
            async with db.execute(
                "SELECT first_name, username FROM user_stats WHERE user_id = ?",
                (top_recipient_id,)
            ) as cursor:
                row = await cursor.fetchone()
                if row:
                    top_recipient_name = (
                        f"@{row['username']}" if row["username"] else row["first_name"]
                    )

        return {
            **base,
            "read_count": read_count,
            "top_recipient_name": top_recipient_name,
            "top_recipient_cnt": top_recipient_cnt,
        }


async def get_leaderboard(limit: int = 10):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT user_id, username, first_name, sent_count, received_count
            FROM user_stats
            WHERE sent_count > 0
            ORDER BY sent_count DESC
            LIMIT ?
        """, (limit,)) as cursor:
            rows = await cursor.fetchall()
            return [dict(r) for r in rows]


async def get_user_count():
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT COUNT(*) FROM user_stats") as cursor:
            row = await cursor.fetchone()
            return row[0] if row else 0


async def upsert_user(user_id: int, username: str | None, first_name: str, now: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            INSERT INTO user_stats (user_id, username, first_name, last_seen)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                username = excluded.username,
                first_name = excluded.first_name,
                last_seen = excluded.last_seen
        """, (user_id, username, first_name, now))
        await db.commit()
